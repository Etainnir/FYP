package com.example.etain.litir_eile;


        import android.gesture.Gesture;
        import android.gesture.Prediction;
        import android.graphics.Color;
        import android.os.Bundle;
        import android.support.design.widget.FloatingActionButton;
        import android.support.design.widget.Snackbar;
        import android.support.v4.content.res.ResourcesCompat;
        import android.support.v7.app.AppCompatActivity;
        import android.util.Log;
        import android.view.View;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.os.Bundle;
        import android.view.MenuItem;
        import android.gesture.GestureLibraries;
        import android.gesture.GestureLibrary;
        import android.gesture.GestureOverlayView;
        import android.gesture.GestureOverlayView.OnGesturePerformedListener;
        import android.widget.ImageButton;
        import android.widget.LinearLayout;
        import android.widget.TextView;
        import android.widget.Toast;

        import android.view.Menu;
        import java.util.ArrayList;


public class draw_letter extends AppCompatActivity implements OnGesturePerformedListener {

    private GestureLibrary gLibrary;
    private int level ;
    private GestureOverlayView gOverlay;

    private String currPaint;

    private final String[] letters = {"s","s","s","a"};

    private final int [] bgletters = new int [] {R.drawable.dot_s,R.drawable.bg_s2, R.drawable.blank};
    String new_name ="Jessica";
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw_letter);

        gLibrary = GestureLibraries.fromRawResource(this, R.raw.gestures);
        if (!gLibrary.load()) {
            finish();
        }

        gOverlay =(GestureOverlayView) findViewById(R.id.gOverlay);
        gOverlay.addOnGesturePerformedListener(this);

        LinearLayout paintLayout = (LinearLayout)findViewById(R.id.paint_colors);
        currPaint = "#000000";

        TextView name = (TextView)findViewById(R.id.user_name);
        if (new_name.length()<=5){
            name.setText(new_name);
        }
        else if (name.length()>5&& name.length()<10){
            name.setTextSize(60);
            name.setText(new_name);
        }
        else {
            name.setTextSize(40);
            name.setText(new_name);
        }


        level = 0;

    }
    public void onGesturePerformed(GestureOverlayView overlay, Gesture
            gesture) {
        ArrayList<Prediction> predictions =
                gLibrary.recognize(gesture);

        if (predictions.size() > 0 && predictions.get(0).score > 2.2) {

            String action = predictions.get(0).name;
           // Log.v(action, action);
            String s =letters[level];
           // Log.v(letters[0],s);

            if (action.trim().equals(s.trim())){
                if (level <2)
                level ++;
                else
                level =0;

                gOverlay.setBackgroundResource(bgletters[level]);
                Toast.makeText(this, "Congrats", Toast.LENGTH_SHORT).show();

            }
            else{


                Toast.makeText(this, "That was the wrong letter", Toast.LENGTH_SHORT).show();
            }

        }

        else {


            Toast.makeText(this, "Oh no try again", Toast.LENGTH_SHORT).show();
        }
        }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_draw_letter, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void paintClicked(View view){
        //use chosen color

            //update color
            ImageButton imgView = (ImageButton)view;
            String colour = view.getTag().toString();
        if(currPaint!=colour){
            gOverlay.setGestureColor(Color.parseColor(colour));
            //currPaint.setImageDrawable(ResourcesCompat.getDrawable(getResources(), R.drawable.colour_choice, null));
            currPaint= colour;
        }
    }
}
